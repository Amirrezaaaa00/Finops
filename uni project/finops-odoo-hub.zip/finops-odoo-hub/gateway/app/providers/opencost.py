from datetime import date, datetime
import hashlib
import httpx
from .base import CostProvider, NormalizedCost


class OpenCostProvider(CostProvider):
    """Adapter for OpenCost Cloud Costs API (/cloudCost).

    The mapping is intentionally tolerant because OpenCost can aggregate by
    different dimensions. When project/department labels are not present,
    values fall back to 'Unallocated'.
    """

    def __init__(self, base_url: str, timeout: float = 20.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    @staticmethod
    def _parse_date(value: str | None) -> date:
        if not value or value == "null":
            return date.today()
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).date()
        except Exception:
            return date.today()

    @staticmethod
    def map_response(payload: dict) -> list[NormalizedCost]:
        rows: list[NormalizedCost] = []
        sets = ((payload or {}).get("data") or {}).get("sets") or []
        for set_idx, cost_set in enumerate(sets):
            cloud_costs = (cost_set or {}).get("cloudCosts") or {}
            for key, item in cloud_costs.items():
                props = (item or {}).get("properties") or {}
                labels = props.get("labels") or {}
                provider = str(props.get("provider") or "Unknown")
                account_id = str(props.get("accountID") or props.get("invoiceEntityID") or "")
                service = str(props.get("service") or "Unknown")
                category = str(props.get("category") or "Other")
                project = str(labels.get("project") or labels.get("team") or labels.get("app") or props.get("project") or "Unallocated")
                department = str(labels.get("department") or labels.get("cost-center") or "Unallocated")
                environment = str(labels.get("environment") or labels.get("env") or "unknown")
                cost_obj = item.get("amortizedNetCost") or item.get("netCost") or item.get("invoicedCost") or item.get("listCost") or {}
                try:
                    cost = float(cost_obj.get("cost") or 0.0)
                except Exception:
                    cost = 0.0
                window = item.get("window") or {}
                usage_date = OpenCostProvider._parse_date(window.get("start"))
                digest = hashlib.sha1(f"{set_idx}:{key}:{usage_date}".encode()).hexdigest()[:16]
                rows.append(NormalizedCost(
                    external_id=f"opencost:{digest}",
                    usage_date=usage_date,
                    provider=provider,
                    account_id=account_id,
                    service=service,
                    category=category,
                    resource=str(props.get("providerID") or key),
                    project=project,
                    department=department,
                    environment=environment,
                    currency="USD",
                    cost=cost,
                    source="opencost",
                ))
        return rows

    async def fetch_costs(self, window: str) -> list[NormalizedCost]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/cloudCost",
                params={"window": window, "aggregate": "provider,service"},
            )
            response.raise_for_status()
            return self.map_response(response.json())
