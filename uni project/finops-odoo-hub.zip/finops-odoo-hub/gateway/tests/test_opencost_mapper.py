from app.providers.opencost import OpenCostProvider


def test_opencost_cloud_cost_mapping():
    payload = {
        "code": 200,
        "data": {"sets": [{"cloudCosts": {
            "AWS/AWSCloudTrail": {
                "properties": {"provider":"AWS","accountID":"123","service":"AWSCloudTrail","category":"Other","labels":{"project":"ERP","department":"IT"}},
                "window": {"start":"2026-09-01T00:00:00Z","end":"2026-09-02T00:00:00Z"},
                "amortizedNetCost": {"cost": 19.8}
            }
        }}]}
    }
    rows = OpenCostProvider.map_response(payload)
    assert len(rows) == 1
    row = rows[0]
    assert row.provider == "AWS"
    assert row.project == "ERP"
    assert row.department == "IT"
    assert row.cost == 19.8
